﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-H3STVF4\SQLEXPRESS;Database=ProductShop2025;Integrated Security=True";
    }
}

﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString 
            = @"Server=DESKTOP-H3STVF4\SQLEXPRESS;Database=CarDealer;Integrated Security=True;Encrypt=False";
    }
}

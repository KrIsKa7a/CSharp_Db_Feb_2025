﻿namespace MusicHub.Data.Configuration
{
    public static class ConnectionConfiguration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-H3STVF4\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
